import { useState } from 'react';
import { ChevronRight, Plus, BarChart2, BarChart, Database, Eye, RefreshCw, Zap, AlertTriangle, Unlink } from 'lucide-react';
import AppShell from '../components/AppShell';
import ConnectModal from '../components/ConnectModal';

interface Connection {
  id: string;
  name: string;
  url: string;
  project: string;
  status: 'connected' | 'warning' | 'disconnected';
  icon: React.ReactNode;
  iconBg: string;
  iconBorder: string;
  stats: { label: string; value: string }[];
  syncInfo: string;
  warning?: string;
  error?: string;
  cardBorder?: string;
  accentGradient: string;
}

const connections: Connection[] = [
  {
    id: 'tableau-acme',
    name: 'Tableau — Acme Corp',
    url: 'tableau.acmecorp.com',
    project: 'Acme Corp migration',
    status: 'connected',
    icon: <BarChart2 size={16} style={{ color: '#60a5fa' }} />,
    iconBg: 'rgba(59,130,246,0.12)',
    iconBorder: 'rgba(59,130,246,0.2)',
    stats: [
      { label: 'Dashboards', value: '48' },
      { label: 'Calc fields', value: '214' },
      { label: 'Data sources', value: '9' },
    ],
    syncInfo: 'Last synced 2 hours ago · PAT token valid',
    accentGradient: 'linear-gradient(90deg, #3b82f6, #60a5fa)',
  },
  {
    id: 'powerbi-globex',
    name: 'Power BI — Globex',
    url: 'Globex · Azure Tenant ID',
    project: 'Globex migration',
    status: 'connected',
    icon: <BarChart size={16} style={{ color: '#fbbf24' }} />,
    iconBg: 'rgba(245,158,11,0.12)',
    iconBorder: 'rgba(245,158,11,0.2)',
    stats: [
      { label: 'Reports', value: '31' },
      { label: 'DAX measures', value: '98' },
      { label: 'Workspaces', value: '5' },
    ],
    syncInfo: 'Last synced 5 hours ago · OAuth valid',
    accentGradient: 'linear-gradient(90deg, #f59e0b, #fbbf24)',
  },
  {
    id: 'domo-acme',
    name: 'Domo — Acme Corp',
    url: 'acmecorp.domo.com',
    project: 'Acme Corp migration',
    status: 'warning',
    icon: <Database size={16} style={{ color: '#ff9900' }} />,
    iconBg: 'rgba(255,153,0,0.12)',
    iconBorder: 'rgba(255,153,0,0.2)',
    stats: [
      { label: 'Cards created', value: '89' },
      { label: 'DataFlows', value: '6' },
      { label: 'Datasets', value: '12' },
    ],
    syncInfo: 'API token expires in 3 days',
    warning: 'API token expires in 3 days — renew before migration pauses',
    cardBorder: 'rgba(245,158,11,0.2)',
    accentGradient: 'linear-gradient(90deg, #ff9900, #ffbc00)',
  },
  {
    id: 'looker-initech',
    name: 'Looker — Initech',
    url: 'acme.looker.com',
    project: 'Initech migration',
    status: 'disconnected',
    icon: <Eye size={16} style={{ color: '#a78bfa' }} />,
    iconBg: 'rgba(167,139,250,0.12)',
    iconBorder: 'rgba(167,139,250,0.2)',
    stats: [
      { label: 'Dashboards', value: '22' },
      { label: 'Last sync', value: '—' },
      { label: 'Auth', value: '—' },
    ],
    syncInfo: 'Last sync failed · Auth error',
    error: 'Client secret expired · Re-authenticate to resume',
    cardBorder: 'rgba(248,113,113,0.2)',
    accentGradient: 'linear-gradient(90deg, #7000ff, #a78bfa)',
  },
];

const statusConfig = {
  connected: { dot: '#34d399', glow: 'rgba(52,211,153,0.5)', label: 'Connected', blink: true },
  warning: { dot: '#fbbf24', glow: 'rgba(251,191,36,0.4)', label: 'Expiring', blink: false },
  disconnected: { dot: '#f87171', glow: 'rgba(248,113,113,0.5)', label: 'Disconnected', blink: false },
};

function StatusBadge({ status }: { status: Connection['status'] }) {
  const cfg = statusConfig[status];
  return (
    <div className="flex items-center gap-1.5">
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: cfg.dot,
        boxShadow: `0 0 5px ${cfg.glow}`,
        animation: cfg.blink ? 'blink 2s ease-in-out infinite' : 'none',
        flexShrink: 0,
      }} />
      <span style={{
        fontSize: 9, fontWeight: 700,
        color: cfg.dot,
        background: status === 'connected' ? 'rgba(52,211,153,0.08)' : status === 'warning' ? 'rgba(251,191,36,0.08)' : 'rgba(248,113,113,0.08)',
        border: `1px solid ${status === 'connected' ? 'rgba(52,211,153,0.2)' : status === 'warning' ? 'rgba(251,191,36,0.2)' : 'rgba(248,113,113,0.2)'}`,
        padding: '2px 6px',
        borderRadius: 100,
      }}>
        {cfg.label}
      </span>
    </div>
  );
}

function ConnectionCard({ conn, onNewConnection }: { conn: Connection; onNewConnection: () => void }) {
  const [hovered, setHovered] = useState(false);

  const btnCyan = {
    background: 'rgba(0,240,255,0.08)', border: '1px solid rgba(0,240,255,0.2)',
    color: '#00f0ff', fontSize: 10, fontWeight: 600, borderRadius: 6,
    padding: '5px 10px', cursor: 'pointer', transition: 'all 0.3s',
  } as const;
  const btnGhost = {
    background: 'transparent', border: '1px solid rgba(255,255,255,0.1)',
    color: '#8fa0dd', fontSize: 10, fontWeight: 600, borderRadius: 6,
    padding: '5px 10px', cursor: 'pointer', transition: 'all 0.3s',
  } as const;
  const btnDanger = {
    background: 'transparent', border: '1px solid rgba(248,113,113,0.2)',
    color: '#f87171', fontSize: 10, fontWeight: 600, borderRadius: 6,
    padding: '5px 10px', cursor: 'pointer', transition: 'all 0.3s',
  } as const;
  const btnAmber = {
    background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.2)',
    color: '#fbbf24', fontSize: 10, fontWeight: 600, borderRadius: 6,
    padding: '5px 10px', cursor: 'pointer', transition: 'all 0.3s',
  } as const;

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: 'rgba(13,17,39,0.60)',
        backdropFilter: 'blur(12px)',
        border: `1px solid ${conn.cardBorder ?? 'rgba(255,255,255,0.06)'}`,
        borderRadius: 14,
        overflow: 'hidden',
        transition: 'all 0.4s cubic-bezier(0.16,1,0.3,1)',
        transform: hovered ? 'translateY(-2px)' : 'none',
        boxShadow: hovered ? '0 8px 32px rgba(0,240,255,0.05)' : 'none',
      }}
    >
      {/* Accent line */}
      <div style={{
        height: 2,
        background: hovered ? conn.accentGradient : 'transparent',
        transition: 'background 0.3s',
      }} />

      <div style={{ padding: '14px 16px' }}>
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: conn.iconBg,
              border: `1px solid ${conn.iconBorder}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              {conn.icon}
            </div>
            <div>
              <p style={{ fontSize: 12, fontWeight: 700, color: 'white' }}>{conn.name}</p>
              <p style={{ fontSize: 9, color: '#8fa0dd', marginTop: 1 }}>{conn.url}</p>
              <span style={{
                fontSize: 9, color: '#8fa0dd',
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 4, padding: '1px 5px',
                marginTop: 3, display: 'inline-block',
              }}>
                {conn.project}
              </span>
            </div>
          </div>
          <StatusBadge status={conn.status} />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          {conn.stats.map(s => (
            <div key={s.label} style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.05)',
              borderRadius: 8, padding: '6px 8px',
              textAlign: 'center',
            }}>
              <p style={{ fontSize: 14, fontWeight: 800, color: 'white' }}>{s.value}</p>
              <p style={{ fontSize: 8, color: '#8fa0dd', marginTop: 1 }}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Warning / Error */}
        {conn.warning && (
          <div className="flex items-center gap-2 mb-3 px-2.5 py-2 rounded-lg" style={{
            background: 'rgba(251,191,36,0.08)',
            border: '1px solid rgba(251,191,36,0.2)',
          }}>
            <AlertTriangle size={11} style={{ color: '#fbbf24', flexShrink: 0 }} />
            <span style={{ fontSize: 9, color: '#fbbf24' }}>{conn.warning}</span>
          </div>
        )}
        {conn.error && (
          <div className="flex items-center gap-2 mb-3 px-2.5 py-2 rounded-lg" style={{
            background: 'rgba(248,113,113,0.08)',
            border: '1px solid rgba(248,113,113,0.2)',
          }}>
            <AlertTriangle size={11} style={{ color: '#f87171', flexShrink: 0 }} />
            <span style={{ fontSize: 9, color: '#f87171' }}>{conn.error}</span>
          </div>
        )}

        {/* Sync info */}
        <p style={{ fontSize: 9, color: '#8fa0dd', marginBottom: 10 }}>{conn.syncInfo}</p>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {conn.status === 'connected' && (
            <>
              <button style={btnCyan} className="flex items-center gap-1">
                <RefreshCw size={9} /> Re-sync
              </button>
              <button style={btnGhost}>Test</button>
              <button style={btnDanger} className="flex items-center gap-1 ml-auto">
                <Unlink size={9} /> Disconnect
              </button>
            </>
          )}
          {conn.status === 'warning' && (
            <>
              <button style={btnAmber}>Renew token</button>
              <button style={btnGhost}>Test</button>
              <button style={btnDanger} className="ml-auto">Disconnect</button>
            </>
          )}
          {conn.status === 'disconnected' && (
            <>
              <button style={btnCyan} className="flex items-center gap-1">
                <Zap size={9} /> Reconnect
              </button>
              <button style={btnGhost}>View logs</button>
              <button style={btnDanger} className="ml-auto">Remove</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Connections() {
  const [modalOpen, setModalOpen] = useState(false);
  const [newHovered, setNewHovered] = useState(false);

  const Breadcrumb = (
    <div className="flex items-center gap-1" style={{ fontSize: 11 }}>
      <span style={{ color: 'white', fontWeight: 600 }}>Connections</span>
      <ChevronRight size={11} style={{ color: '#8fa0dd' }} />
      <span style={{ color: '#8fa0dd' }}>MCP accounts</span>
    </div>
  );

  return (
    <>
      <AppShell
        topbarLeft={Breadcrumb}
        topbarRight={
          <button
            onClick={() => setModalOpen(true)}
            className="btn-primary flex items-center gap-1.5 px-4 py-2 text-xs font-semibold"
          >
            <Plus size={13} /> New connection
          </button>
        }
      >
        <div className="p-5 flex flex-col gap-5">
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <StatCard label="TOTAL" value="5" valueColor="#f1f3f9" sub="" />
            <StatCard label="CONNECTED" value="3" valueColor="#34d399" sub="All systems go" subColor="#34d399" />
            <StatCard label="WARNING" value="1" valueColor="#fbbf24" sub="Token expiring" subColor="#fbbf24" />
            <StatCard label="DISCONNECTED" value="1" valueColor="#f87171" sub="Auth required" subColor="#f87171" />
          </div>

          {/* Section label */}
          <p style={{ fontSize: 10, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Active connections
          </p>

          {/* Cards grid */}
          <div className="grid md:grid-cols-2 gap-4">
            {connections.map(conn => (
              <ConnectionCard key={conn.id} conn={conn} onNewConnection={() => setModalOpen(true)} />
            ))}

            {/* New connection card */}
            <button
              onClick={() => setModalOpen(true)}
              onMouseEnter={() => setNewHovered(true)}
              onMouseLeave={() => setNewHovered(false)}
              className="flex flex-col items-center justify-center gap-3 rounded-2xl transition-all duration-300"
              style={{
                border: `1.5px dashed ${newHovered ? 'rgba(0,240,255,0.3)' : 'rgba(255,255,255,0.1)'}`,
                background: newHovered ? 'rgba(0,240,255,0.03)' : 'transparent',
                minHeight: 180,
                cursor: 'pointer',
                padding: 24,
              }}
            >
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                border: '1.5px dashed rgba(255,255,255,0.15)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Plus size={16} style={{ color: 'rgba(143,160,221,0.6)' }} />
              </div>
              <div style={{ textAlign: 'center' }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: 'white', marginBottom: 4 }}>Add new connection</p>
                <p style={{ fontSize: 9, color: '#8fa0dd' }}>Tableau · Power BI · Looker · Quicksight · Domo</p>
              </div>
            </button>
          </div>
        </div>
      </AppShell>

      {modalOpen && <ConnectModal onClose={() => setModalOpen(false)} />}
    </>
  );
}

function StatCard({ label, value, valueColor, sub, subColor }: {
  label: string; value: string; valueColor?: string; sub?: string; subColor?: string;
}) {
  return (
    <div style={{
      background: 'rgba(13,17,39,0.60)',
      backdropFilter: 'blur(12px)',
      border: '1px solid rgba(255,255,255,0.06)',
      borderRadius: 10,
      padding: '10px 12px',
    }}>
      <p style={{ fontSize: 9, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>{label}</p>
      <p style={{ fontSize: 18, fontWeight: 800, color: valueColor || '#f1f3f9', lineHeight: 1 }}>{value}</p>
      {sub && <p style={{ fontSize: 9, color: subColor || '#8fa0dd', marginTop: 3 }}>{sub}</p>}
    </div>
  );
}
