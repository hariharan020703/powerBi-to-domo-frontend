import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, BarChart2, FileText, Eye, ArrowRight, ChevronUp } from 'lucide-react';
import AppShell from '../components/AppShell';
import ConnectModal from '../components/ConnectModal';

const projects = [
  {
    id: 'acme',
    name: 'Acme Corp',
    subtitle: 'Tableau · 48 dashboards',
    icon: <BarChart2 size={16} style={{ color: '#60a5fa' }} />,
    iconBg: 'rgba(96,165,250,0.12)',
    status: 'Active',
    statusColor: '#34d399',
    progress: 72,
    progressColor: 'linear-gradient(90deg, #7000ff, #00f0ff)',
    chips: [
      { label: '22 easy', color: '#34d399' },
      { label: '18 medium', color: '#fbbf24' },
      { label: '8 complex', color: '#f87171' },
    ],
    date: 'Apr 12',
  },
  {
    id: 'globex',
    name: 'Globex',
    subtitle: 'Power BI · 31 dashboards',
    icon: <FileText size={16} style={{ color: '#fbbf24' }} />,
    iconBg: 'rgba(251,191,36,0.12)',
    status: 'Active',
    statusColor: '#34d399',
    progress: 38,
    progressColor: 'linear-gradient(90deg, #7000ff, #00f0ff)',
    chips: [
      { label: '10 easy', color: '#34d399' },
      { label: '14 medium', color: '#fbbf24' },
      { label: '7 complex', color: '#f87171' },
    ],
    date: 'May 3',
  },
  {
    id: 'initech',
    name: 'Initech',
    subtitle: 'Looker · 22 dashboards',
    icon: <Eye size={16} style={{ color: '#c084fc' }} />,
    iconBg: 'rgba(192,132,252,0.12)',
    status: 'Pending',
    statusColor: '#fbbf24',
    progress: 5,
    progressColor: 'linear-gradient(90deg, #fbbf24, #f59e0b)',
    chips: [{ label: 'Audit in progress', color: '#fbbf24' }],
    date: 'May 20',
  },
];

type Tab = 'All' | 'Active' | 'Completed' | 'Draft';

export default function Projects() {
  const [tab, setTab] = useState<Tab>('All');
  const [modalOpen, setModalOpen] = useState(false);

  const filtered = projects.filter(p => {
    if (tab === 'All') return true;
    if (tab === 'Active') return p.status === 'Active';
    if (tab === 'Completed') return p.progress === 100;
    if (tab === 'Draft') return p.status === 'Pending';
    return true;
  });

  const tabs: { label: Tab; count?: number }[] = [
    { label: 'All', count: 4 },
    { label: 'Active' },
    { label: 'Completed' },
    { label: 'Draft' },
  ];

  return (
    <>
      <AppShell
        topbarLeft={<h1 className="font-bold text-base text-white">Projects</h1>}
        topbarRight={
          <button
            onClick={() => setModalOpen(true)}
            className="btn-primary flex items-center gap-1.5 px-4 py-2 text-xs font-semibold"
          >
            <Plus size={13} /> New project
          </button>
        }
      >
        <div className="p-6 max-w-6xl">
          {/* Stats row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-7">
            <StatCard label="Total projects" value="4" />
            <StatCard
              label="Dashboards"
              value="147"
              extra={
                <span className="flex items-center gap-0.5 text-[10px] font-semibold" style={{ color: '#34d399' }}>
                  <ChevronUp size={11} /> 12 this week
                </span>
              }
            />
            <StatCard
              label="Migrated"
              value="89"
              extra={<span className="text-[10px]" style={{ color: '#8fa0dd' }}>61% complete</span>}
            />
            <StatCard
              label="Pending review"
              value="14"
              extra={<span className="text-[10px]" style={{ color: '#fbbf24' }}>UAT in progress</span>}
            />
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1 mb-6">
            {tabs.map(t => (
              <button
                key={t.label}
                onClick={() => setTab(t.label)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-300"
                style={
                  tab === t.label
                    ? {
                        background: 'rgba(0,240,255,0.08)',
                        border: '1px solid rgba(0,240,255,0.12)',
                        color: '#00f0ff',
                      }
                    : {
                        background: 'transparent',
                        border: '1px solid transparent',
                        color: '#8fa0dd',
                      }
                }
              >
                {t.label}
                {t.count !== undefined && (
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold"
                    style={{
                      background: tab === t.label ? 'rgba(0,240,255,0.15)' : 'rgba(255,255,255,0.06)',
                      color: tab === t.label ? '#00f0ff' : '#8fa0dd',
                    }}
                  >
                    {t.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Projects grid */}
          <div className="grid md:grid-cols-2 gap-4">
            {filtered.map(p => (
              <div
                key={p.id}
                className="card p-5 flex flex-col gap-4"
              >
                {/* Top */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: p.iconBg }}
                    >
                      {p.icon}
                    </div>
                    <div>
                      <p className="font-bold text-sm text-white">{p.name}</p>
                      <p className="text-[11px]" style={{ color: '#8fa0dd' }}>{p.subtitle}</p>
                    </div>
                  </div>
                  <span
                    className="text-[10px] font-semibold px-2 py-1 rounded-full"
                    style={{
                      background: `${p.statusColor}18`,
                      border: `1px solid ${p.statusColor}33`,
                      color: p.statusColor,
                    }}
                  >
                    {p.status}
                  </span>
                </div>

                {/* Progress */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-medium" style={{ color: '#8fa0dd' }}>Progress</span>
                    <span className="text-[10px] font-bold text-white">{p.progress}%</span>
                  </div>
                  <div
                    className="w-full rounded-full overflow-hidden"
                    style={{ height: 5, background: 'rgba(255,255,255,0.06)' }}
                  >
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${p.progress}%`, background: p.progressColor }}
                    />
                  </div>
                </div>

                {/* Chips */}
                <div className="flex flex-wrap gap-1.5">
                  {p.chips.map(c => (
                    <span
                      key={c.label}
                      className="text-[9px] font-semibold px-2 py-1 rounded-full"
                      style={{
                        background: `${c.color}18`,
                        border: `1px solid ${c.color}33`,
                        color: c.color,
                      }}
                    >
                      {c.label}
                    </span>
                  ))}
                </div>

                {/* Footer */}
                <div
                  className="flex items-center justify-between pt-3"
                  style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}
                >
                  <span className="text-[10px]" style={{ color: '#8fa0dd' }}>{p.date}</span>
                  <Link
                    to={`/app/project/${p.id}`}
                    className="flex items-center gap-1 text-xs font-semibold transition-colors duration-300"
                    style={{ color: '#00f0ff' }}
                  >
                    Open <ArrowRight size={12} />
                  </Link>
                </div>
              </div>
            ))}

            {/* New project card */}
            <button
              onClick={() => setModalOpen(true)}
              className="flex flex-col items-center justify-center p-8 rounded-2xl transition-all duration-300 group cursor-pointer"
              style={{
                border: '1.5px dashed rgba(255,255,255,0.1)',
                background: 'transparent',
                minHeight: 200,
              }}
              onMouseOver={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,240,255,0.3)';
                (e.currentTarget as HTMLElement).style.background = 'rgba(0,240,255,0.03)';
              }}
              onMouseOut={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.1)';
                (e.currentTarget as HTMLElement).style.background = 'transparent';
              }}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center mb-3 transition-all duration-300"
                style={{
                  border: '1.5px dashed rgba(255,255,255,0.15)',
                }}
              >
                <Plus size={18} style={{ color: 'rgba(143,160,221,0.6)' }} />
              </div>
              <p className="font-semibold text-sm mb-1 text-white">New project</p>
              <p className="text-xs text-center" style={{ color: '#8fa0dd' }}>
                Connect Tableau, Power BI, Looker or Quicksight
              </p>
            </button>
          </div>
        </div>
      </AppShell>

      {modalOpen && <ConnectModal onClose={() => setModalOpen(false)} />}
    </>
  );
}

function StatCard({ label, value, extra }: { label: string; value: string; extra?: React.ReactNode }) {
  return (
    <div className="card p-4 flex flex-col gap-1">
      <p className="text-xs" style={{ color: '#8fa0dd' }}>{label}</p>
      <p className="text-2xl font-extrabold text-white">{value}</p>
      {extra && <div>{extra}</div>}
    </div>
  );
}
