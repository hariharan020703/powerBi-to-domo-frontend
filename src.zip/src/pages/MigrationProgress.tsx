import { ChevronRight, Sparkles, CheckCircle, AlertCircle, Loader, Clock } from 'lucide-react';
import AppShell from '../components/AppShell';

const waveData = [
  { name: 'Wave 1 — Easy', count: 22, progress: 100, status: '✓ Complete', statusColor: '#34d399', barBg: 'linear-gradient(90deg, #00f0ff, #7000ff)' },
  { name: 'Wave 2 — Medium', count: 18, progress: 50, status: '9 of 18 · In progress', statusColor: '#a78bfa', barBg: 'linear-gradient(90deg, #7000ff, #a78bfa)' },
  { name: 'Wave 3 — Complex', count: 8, progress: 8, status: 'Not started', statusColor: '#8fa0dd', barBg: 'rgba(255,255,255,0.1)' },
];

const timeline = [
  { label: 'Project started', date: 'Apr 12', color: '#34d399', glow: 'rgba(52,211,153,0.5)', blink: false },
  { label: 'Wave 1 complete', date: 'Apr 28', color: '#34d399', glow: 'rgba(52,211,153,0.5)', blink: false },
  { label: 'Wave 2 in progress', date: 'Now', color: '#00f0ff', glow: 'rgba(0,240,255,0.5)', blink: true },
  { label: 'Wave 3 starts', date: 'Jun 2', color: 'rgba(255,255,255,0.15)', glow: 'transparent', blink: false },
  { label: 'Est. completion', date: 'Jun 18', color: 'rgba(255,255,255,0.15)', glow: 'transparent', blink: false },
];

const execItems = [
  {
    id: 1,
    name: 'Global Sales Performance',
    subtitle: 'In progress · 14m',
    state: 'active' as const,
    tags: [
      { label: 'Beast Mode ×34', bg: 'rgba(0,240,255,0.1)', border: 'rgba(0,240,255,0.2)', color: '#00f0ff' },
      { label: 'ETL mapping', bg: 'rgba(112,0,255,0.1)', border: 'rgba(112,0,255,0.2)', color: '#c084fc' },
      { label: 'DataFlow', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399' },
    ],
    detail: 'Rewriting LOD FIXED [Region] → window function. 28 of 34 Beast Mode formulas complete.',
    detailHighlights: ['LOD FIXED [Region]', 'window function', '28 of 34'],
  },
  {
    id: 2,
    name: 'Revenue by Region',
    subtitle: 'Complete',
    state: 'done' as const,
    tags: [
      { label: 'Beast Mode ×18', bg: 'rgba(0,240,255,0.1)', border: 'rgba(0,240,255,0.2)', color: '#00f0ff' },
      { label: '18 fields mapped', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399' },
      { label: 'DataFlow built', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399' },
    ],
    detail: 'All 18 calculated fields translated. Snowflake connector verified. Card live in Domo.',
    detailHighlights: ['18 calculated fields', 'Snowflake', 'live in Domo'],
  },
  {
    id: 3,
    name: 'Customer Cohort Analysis',
    subtitle: 'Error — action needed',
    state: 'error' as const,
    tags: [
      { label: 'LOD unsupported', bg: 'rgba(248,113,113,0.1)', border: 'rgba(248,113,113,0.2)', color: '#f87171' },
      { label: 'Beast Mode ×12', bg: 'rgba(0,240,255,0.1)', border: 'rgba(0,240,255,0.2)', color: '#00f0ff' },
    ],
    detail: 'EXCLUDE LOD has no direct Beast Mode equivalent. Clarify has suggested a workaround — awaiting approval.',
    detailHighlights: ['EXCLUDE LOD', 'no direct Beast Mode equivalent', 'awaiting approval'],
  },
  {
    id: 4,
    name: 'Weekly KPI Scorecard',
    subtitle: 'Complete',
    state: 'done' as const,
    tags: [
      { label: 'Beast Mode ×6', bg: 'rgba(0,240,255,0.1)', border: 'rgba(0,240,255,0.2)', color: '#00f0ff' },
      { label: '6 fields mapped', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399' },
    ],
    detail: 'Simple dashboard. All 6 fields mapped directly. No LOD expressions. Card live in Domo.',
    detailHighlights: ['6 fields', 'No LOD expressions', 'live in Domo'],
  },
  {
    id: 5,
    name: 'Product Health Monitor',
    subtitle: 'Complete',
    state: 'done' as const,
    tags: [
      { label: 'Beast Mode ×4', bg: 'rgba(0,240,255,0.1)', border: 'rgba(0,240,255,0.2)', color: '#00f0ff' },
      { label: '4 fields mapped', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399' },
    ],
    detail: 'Fastest migration. PostgreSQL connector auto-detected. All cards verified.',
    detailHighlights: ['PostgreSQL', 'auto-detected', 'All cards verified'],
  },
];

type ExecFilter = 'All' | 'Beast Mode' | 'ETL' | 'Errors';

function highlightText(text: string, highlights: string[]) {
  let result: (string | JSX.Element)[] = [text];
  highlights.forEach(h => {
    result = result.flatMap(part => {
      if (typeof part !== 'string') return [part];
      const idx = part.indexOf(h);
      if (idx === -1) return [part];
      return [
        part.slice(0, idx),
        <span key={h} style={{ color: '#00f0ff' }}>{h}</span>,
        part.slice(idx + h.length),
      ];
    });
  });
  return result;
}

const CIRCUMFERENCE = 2 * Math.PI * 40; // r=40

export default function MigrationProgress() {
  const Breadcrumb = (
    <div className="flex items-center gap-1" style={{ fontSize: 11 }}>
      <span style={{ color: '#8fa0dd' }}>Projects</span>
      <ChevronRight size={11} style={{ color: '#8fa0dd' }} />
      <span style={{ color: '#8fa0dd' }}>Acme Corp</span>
      <ChevronRight size={11} style={{ color: '#8fa0dd' }} />
      <span style={{ color: 'white', fontWeight: 600 }}>Migration Progress</span>
    </div>
  );

  const TopRight = (
    <div
      className="flex items-center gap-2 px-3 py-1"
      style={{
        background: 'rgba(167,139,250,0.1)',
        border: '1px solid rgba(167,139,250,0.25)',
        borderRadius: 20,
        fontSize: 10,
        color: '#a78bfa',
      }}
    >
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: '#a78bfa',
        animation: 'blink 2s ease-in-out infinite',
        boxShadow: '0 0 5px rgba(167,139,250,0.6)',
      }} />
      Migration in progress
    </div>
  );

  return (
    <AppShell topbarLeft={Breadcrumb} topbarRight={TopRight}>
      <div className="p-5 flex gap-5 h-full">
        {/* Left panel */}
        <div className="flex flex-col gap-4 flex-shrink-0" style={{ width: 210 }}>
          {/* Circular progress */}
          <div
            style={{
              background: 'rgba(13,17,39,0.60)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 14,
              padding: '16px 12px',
            }}
          >
            <div className="flex justify-center mb-3">
              <div className="relative" style={{ width: 96, height: 96 }}>
                <svg width="96" height="96" viewBox="0 0 96 96" style={{ transform: 'rotate(-90deg)' }}>
                  <defs>
                    <linearGradient id="progressGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#00f0ff" />
                      <stop offset="100%" stopColor="#7000ff" />
                    </linearGradient>
                  </defs>
                  <circle cx="48" cy="48" r="40" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
                  <circle
                    cx="48" cy="48" r="40" fill="none"
                    stroke="url(#progressGrad)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={CIRCUMFERENCE}
                    strokeDashoffset={CIRCUMFERENCE * (1 - 0.64)}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span style={{ fontSize: 22, fontWeight: 800, color: '#00f0ff', lineHeight: 1 }}>64%</span>
                  <span style={{ fontSize: 9, color: '#8fa0dd', marginTop: 2 }}>complete</span>
                </div>
              </div>
            </div>
            <p style={{ fontSize: 11, fontWeight: 700, color: 'white', textAlign: 'center' }}>Acme Corp — Tableau</p>
            <p style={{ fontSize: 9, color: '#8fa0dd', textAlign: 'center', marginTop: 2 }}>31 of 48 dashboards migrated</p>
          </div>

          {/* Wave plan */}
          <div
            style={{
              background: 'rgba(13,17,39,0.60)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 14,
              padding: '12px',
            }}
          >
            <p style={{ fontSize: 9, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
              Wave Plan
            </p>
            <div className="flex flex-col gap-3">
              {waveData.map((w, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <span style={{ fontSize: 9, fontWeight: 600, color: 'white' }}>{w.name}</span>
                    <span style={{ fontSize: 9, color: '#8fa0dd' }}>{w.count}</span>
                  </div>
                  <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden', marginBottom: 3 }}>
                    <div style={{ height: '100%', width: `${w.progress}%`, background: w.barBg, borderRadius: 2 }} />
                  </div>
                  <span style={{ fontSize: 8, color: w.statusColor }}>{w.status}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Timeline */}
          <div
            style={{
              background: 'rgba(13,17,39,0.60)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 14,
              padding: '12px',
            }}
          >
            <p style={{ fontSize: 9, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
              Timeline
            </p>
            <div className="relative flex flex-col gap-0">
              {timeline.map((t, i) => (
                <div key={i} className="flex items-start gap-2 relative">
                  {/* Connector line */}
                  {i < timeline.length - 1 && (
                    <div
                      style={{
                        position: 'absolute',
                        left: 4,
                        top: 10,
                        width: 1,
                        height: 20,
                        background: 'rgba(255,255,255,0.08)',
                      }}
                    />
                  )}
                  <div
                    style={{
                      width: 9,
                      height: 9,
                      borderRadius: '50%',
                      background: t.color,
                      boxShadow: t.glow !== 'transparent' ? `0 0 5px ${t.glow}` : 'none',
                      animation: t.blink ? 'blink 2s ease-in-out infinite' : 'none',
                      flexShrink: 0,
                      marginTop: 1,
                    }}
                  />
                  <div className="flex items-center justify-between flex-1 pb-3">
                    <span style={{ fontSize: 9, color: t.color === 'rgba(255,255,255,0.15)' ? '#8fa0dd' : 'white', fontWeight: 500 }}>
                      {t.label}
                    </span>
                    <span style={{ fontSize: 9, color: '#8fa0dd' }}>{t.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Stats grid */}
          <div
            style={{
              background: 'rgba(13,17,39,0.60)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 14,
              padding: '12px',
            }}
          >
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Beast Mode formulas', value: '214' },
                { label: 'DataFlows built', value: '9' },
                { label: 'Fields mapped', value: '186' },
                { label: 'Avg per dashboard', value: '2.4h' },
              ].map(s => (
                <div key={s.label}
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    borderRadius: 8,
                    padding: '8px',
                  }}
                >
                  <p style={{
                    fontSize: 16,
                    fontWeight: 800,
                    background: 'linear-gradient(135deg, #00f0ff, #7000ff)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                    lineHeight: 1,
                  }}>
                    {s.value}
                  </p>
                  <p style={{ fontSize: 8, color: '#8fa0dd', marginTop: 3, lineHeight: 1.3 }}>{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          {/* Claude ticker */}
          <div
            style={{
              background: 'rgba(167,139,250,0.06)',
              border: '1px solid rgba(167,139,250,0.2)',
              borderRadius: 10,
              padding: '10px 14px',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}
          >
            <div
              style={{
                width: 24, height: 24, borderRadius: '50%',
                background: 'linear-gradient(135deg, #00f0ff, #7000ff)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <Sparkles size={12} color="white" />
            </div>
            <div className="flex-1 min-w-0">
              <p style={{ fontSize: 9, fontWeight: 600, color: '#a78bfa', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 2 }}>
                Migration in progress
              </p>
              <p style={{ fontSize: 11, color: '#c0bfe8', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                Translating{' '}
                <span style={{ color: '#00f0ff' }}>LOD FIXED expression</span>
                {' '}in{' '}
                <span style={{ color: '#00f0ff' }}>"Global Sales Performance"</span>
                {' '}→{' '}
                <span style={{ color: '#00f0ff' }}>Beast Mode window function</span>
              </p>
            </div>
            <span style={{ fontSize: 9, color: '#8fa0dd', flexShrink: 0 }}>2m ago</span>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-1.5">
            {(['All', 'Beast Mode', 'ETL', 'Errors'] as ExecFilter[]).map(t => (
              <button
                key={t}
                style={{
                  background: t === 'All' ? 'rgba(0,240,255,0.1)' : 'transparent',
                  border: `1px solid ${t === 'All' ? 'rgba(0,240,255,0.3)' : 'rgba(255,255,255,0.07)'}`,
                  color: t === 'All' ? '#00f0ff' : '#8fa0dd',
                  fontWeight: t === 'All' ? 600 : 400,
                  fontSize: 11,
                  padding: '4px 10px',
                  borderRadius: 20,
                  cursor: 'pointer',
                  transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)',
                }}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Execution log */}
          <div className="flex flex-col gap-3">
            {execItems.map(item => (
              <ExecCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function ExecCard({ item }: { item: typeof execItems[0] }) {
  const isActive = item.state === 'active';
  const isDone = item.state === 'done';
  const isError = item.state === 'error';

  return (
    <div
      style={{
        background: isActive ? 'rgba(167,139,250,0.05)' : 'rgba(13,17,39,0.60)',
        backdropFilter: 'blur(12px)',
        border: `1px solid ${isActive ? 'rgba(167,139,250,0.3)' : isError ? 'rgba(248,113,113,0.15)' : 'rgba(255,255,255,0.06)'}`,
        borderRadius: 12,
        padding: '12px 14px',
        transition: 'all 0.4s cubic-bezier(0.16,1,0.3,1)',
      }}
    >
      <div className="flex items-start gap-3">
        {/* Icon */}
        <div
          style={{
            width: 28, height: 28, borderRadius: 8,
            background: isActive ? 'rgba(167,139,250,0.12)' : isDone ? 'rgba(52,211,153,0.1)' : 'rgba(248,113,113,0.1)',
            border: `1px solid ${isActive ? 'rgba(167,139,250,0.25)' : isDone ? 'rgba(52,211,153,0.2)' : 'rgba(248,113,113,0.2)'}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          {isActive && <Loader size={13} style={{ color: '#a78bfa', animation: 'spin 1.5s linear infinite' }} />}
          {isDone && <CheckCircle size={13} style={{ color: '#34d399' }} />}
          {isError && <AlertCircle size={13} style={{ color: '#f87171' }} />}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span style={{ fontSize: 12, fontWeight: 700, color: 'white' }}>{item.name}</span>
            <span style={{ fontSize: 9, color: isActive ? '#a78bfa' : isDone ? '#34d399' : '#f87171', flexShrink: 0 }}>
              {item.subtitle}
            </span>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5 mb-2">
            {item.tags.map((tag, i) => (
              <span
                key={i}
                style={{
                  background: tag.bg,
                  border: `1px solid ${tag.border}`,
                  color: tag.color,
                  fontSize: 9,
                  fontWeight: 600,
                  padding: '2px 6px',
                  borderRadius: 4,
                }}
              >
                {tag.label}
              </span>
            ))}
          </div>

          <p style={{ fontSize: 10, color: '#8fa0dd', lineHeight: 1.5 }}>
            {highlightText(item.detail, item.detailHighlights)}
          </p>
        </div>
      </div>
    </div>
  );
}
