import { useState } from 'react';
import { ChevronRight, Search, RefreshCw } from 'lucide-react';
import AppShell from '../components/AppShell';

type Complexity = 'easy' | 'medium' | 'complex';
type Status = 'in-progress' | 'migrated' | 'error' | 'pending';

interface Dashboard {
  name: string;
  workbook: string;
  source: string;
  complexity: Complexity;
  status: Status;
  fields: number;
  dataSource: string;
}

const dashboards: Dashboard[] = [
  { name: 'Global Sales Performance', workbook: 'Sales Workbook v3', source: 'Tableau', complexity: 'complex', status: 'in-progress', fields: 34, dataSource: 'Snowflake' },
  { name: 'Revenue by Region', workbook: 'Finance Workbook', source: 'Tableau', complexity: 'medium', status: 'migrated', fields: 18, dataSource: 'Snowflake' },
  { name: 'Customer Cohort Analysis', workbook: 'Marketing Workbook', source: 'Tableau', complexity: 'complex', status: 'error', fields: 41, dataSource: 'BigQuery' },
  { name: 'Weekly KPI Scorecard', workbook: 'Exec Workbook', source: 'Tableau', complexity: 'easy', status: 'migrated', fields: 6, dataSource: 'Redshift' },
  { name: 'Supply Chain Overview', workbook: 'Operations Workbook', source: 'Tableau', complexity: 'medium', status: 'pending', fields: 14, dataSource: 'MySQL' },
  { name: 'Product Health Monitor', workbook: 'Product Workbook', source: 'Tableau', complexity: 'easy', status: 'migrated', fields: 4, dataSource: 'PostgreSQL' },
  { name: 'Campaign Attribution', workbook: 'Marketing Workbook', source: 'Tableau', complexity: 'complex', status: 'pending', fields: 28, dataSource: 'BigQuery' },
];

const MAX_FIELDS = 41;

const complexityConfig: Record<Complexity, { bg: string; border: string; color: string; label: string }> = {
  easy: { bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)', color: '#34d399', label: 'Easy' },
  medium: { bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)', color: '#fbbf24', label: 'Medium' },
  complex: { bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.2)', color: '#f87171', label: 'Complex' },
};

const statusConfig: Record<Status, { dot: string; glow: string; label: string; blink?: boolean }> = {
  'migrated': { dot: '#00f0ff', glow: 'rgba(0,240,255,0.5)', label: 'Migrated' },
  'in-progress': { dot: '#a78bfa', glow: 'rgba(167,139,250,0.5)', label: 'In progress', blink: true },
  'pending': { dot: 'rgba(255,255,255,0.2)', glow: 'transparent', label: 'Pending' },
  'error': { dot: '#f87171', glow: 'rgba(248,113,113,0.5)', label: 'Error' },
};

const fieldBarColor: Record<Status, string> = {
  'migrated': 'linear-gradient(90deg, #34d399, #00f0ff)',
  'in-progress': 'linear-gradient(90deg, #7000ff, #a78bfa)',
  'error': '#f87171',
  'pending': '#fbbf24',
};

type Tab = 'All' | 'Easy' | 'Medium' | 'Complex' | 'Migrated' | 'Errors';
const tabs: { label: Tab; count: number }[] = [
  { label: 'All', count: 48 },
  { label: 'Easy', count: 22 },
  { label: 'Medium', count: 18 },
  { label: 'Complex', count: 8 },
  { label: 'Migrated', count: 31 },
  { label: 'Errors', count: 2 },
];

function StatusPill({ status }: { status: Status }) {
  const cfg = statusConfig[status];
  return (
    <div className="flex items-center gap-1.5">
      <div
        style={{
          width: 5,
          height: 5,
          borderRadius: '50%',
          background: cfg.dot,
          boxShadow: cfg.glow !== 'transparent' ? `0 0 5px ${cfg.glow}` : 'none',
          animation: cfg.blink ? 'blink 2s ease-in-out infinite' : 'none',
          flexShrink: 0,
        }}
      />
      <span style={{ fontSize: 9, fontWeight: 700, color: cfg.dot === 'rgba(255,255,255,0.2)' ? '#8fa0dd' : cfg.dot }}>
        {cfg.label}
      </span>
    </div>
  );
}

function ComplexityBadge({ c }: { c: Complexity }) {
  const cfg = complexityConfig[c];
  return (
    <span
      style={{
        background: cfg.bg,
        border: `1px solid ${cfg.border}`,
        color: cfg.color,
        borderRadius: 100,
        fontSize: 9,
        fontWeight: 700,
        padding: '2px 7px',
      }}
    >
      {cfg.label}
    </span>
  );
}

function ActionButtons({ status }: { status: Status }) {
  const actionStyle = {
    background: 'rgba(0,240,255,0.08)',
    border: '1px solid rgba(0,240,255,0.2)',
    color: '#00f0ff',
    fontSize: 9,
    fontWeight: 700,
    borderRadius: 5,
    padding: '3px 7px',
    cursor: 'pointer',
    transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)',
  } as const;

  const dangerStyle = {
    ...actionStyle,
    background: 'rgba(248,113,113,0.08)',
    border: '1px solid rgba(248,113,113,0.2)',
    color: '#f87171',
  } as const;

  const ghostStyle = {
    ...actionStyle,
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.1)',
    color: '#8fa0dd',
  } as const;

  if (status === 'in-progress') return (
    <div className="flex gap-1 row-actions">
      <button style={actionStyle}>View</button>
      <button style={ghostStyle}>Pause</button>
    </div>
  );
  if (status === 'migrated') return (
    <div className="flex gap-1 row-actions">
      <button style={actionStyle}>View in Domo</button>
    </div>
  );
  if (status === 'error') return (
    <div className="flex gap-1 row-actions">
      <button style={dangerStyle}>Retry</button>
      <button style={ghostStyle}>Debug</button>
    </div>
  );
  return (
    <div className="flex gap-1 row-actions">
      <button style={actionStyle}>Start</button>
    </div>
  );
}

export default function DashboardInventory() {
  const [tab, setTab] = useState<Tab>('All');
  const [search, setSearch] = useState('');

  const filtered = dashboards.filter(d => {
    const matchTab =
      tab === 'All' ? true :
      tab === 'Easy' ? d.complexity === 'easy' :
      tab === 'Medium' ? d.complexity === 'medium' :
      tab === 'Complex' ? d.complexity === 'complex' :
      tab === 'Migrated' ? d.status === 'migrated' :
      tab === 'Errors' ? d.status === 'error' :
      true;
    const matchSearch = search === '' || d.name.toLowerCase().includes(search.toLowerCase());
    return matchTab && matchSearch;
  });

  const Breadcrumb = (
    <div className="flex items-center gap-1" style={{ fontSize: 11 }}>
      <span style={{ color: '#8fa0dd' }}>Projects</span>
      <ChevronRight size={11} style={{ color: '#8fa0dd' }} />
      <span style={{ color: '#8fa0dd' }}>Acme Corp</span>
      <ChevronRight size={11} style={{ color: '#8fa0dd' }} />
      <span style={{ color: 'white', fontWeight: 600 }}>Dashboards</span>
    </div>
  );

  const TopRight = (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: '#8fa0dd' }} />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search dashboards..."
          className="miq-input pl-7 pr-3 py-1.5 text-xs"
          style={{ width: 180 }}
        />
      </div>
      <button
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-300"
        style={{
          background: 'rgba(0,240,255,0.08)',
          border: '1px solid rgba(0,240,255,0.2)',
          color: '#00f0ff',
          cursor: 'pointer',
        }}
      >
        <RefreshCw size={11} />
        Re-sync MCP
      </button>
    </div>
  );

  return (
    <AppShell topbarLeft={Breadcrumb} topbarRight={TopRight}>
      <div className="p-5 flex flex-col gap-5">
        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          <StatCard icon="📊" label="TOTAL" value="48" sub="Fetched via MCP" subColor="#8fa0dd" />
          <StatCard icon="✓" label="MIGRATED" value="31" valueColor="#00f0ff" sub="64% complete" subColor="#34d399" />
          <StatCard icon="↻" label="IN PROGRESS" value="6" valueColor="#a78bfa" sub="Migration in progress" subColor="#a78bfa" />
          <StatCard icon="○" label="PENDING" value="9" valueColor="white" sub="Not started" subColor="#8fa0dd" />
          <StatCard icon="!" label="ERRORS" value="2" valueColor="#f87171" sub="Needs review" subColor="#f87171" />
        </div>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-1.5">
          {tabs.map(t => (
            <button
              key={t.label}
              onClick={() => setTab(t.label)}
              style={tab === t.label ? {
                background: 'rgba(0,240,255,0.1)',
                border: '1px solid rgba(0,240,255,0.3)',
                color: '#00f0ff',
                fontWeight: 600,
                fontSize: 11,
                padding: '4px 10px',
                borderRadius: 20,
                cursor: 'pointer',
                transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)',
              } : {
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.07)',
                color: '#8fa0dd',
                fontWeight: 400,
                fontSize: 11,
                padding: '4px 10px',
                borderRadius: 20,
                cursor: 'pointer',
                transition: 'all 0.3s cubic-bezier(0.16,1,0.3,1)',
              }}
            >
              {t.label} <span style={{ opacity: 0.6 }}>({t.count})</span>
            </button>
          ))}
        </div>

        {/* Table */}
        <div
          className="rounded-xl overflow-hidden"
          style={{
            background: 'rgba(13,17,39,0.60)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          {/* Header */}
          <div
            className="grid text-left"
            style={{
              gridTemplateColumns: '2fr 1fr 80px 90px 110px 90px 100px',
              background: 'rgba(255,255,255,0.03)',
              borderBottom: '1px solid rgba(255,255,255,0.06)',
              padding: '8px 14px',
              gap: 8,
            }}
          >
            {['Dashboard', 'Source', 'Complexity', 'Status', 'Calc fields', 'Data source', 'Action'].map(h => (
              <span key={h} style={{ fontSize: 9, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {h}
              </span>
            ))}
          </div>

          {/* Rows */}
          {filtered.map((d, i) => (
            <TableRow key={i} d={d} />
          ))}

          {filtered.length === 0 && (
            <div className="flex items-center justify-center py-10" style={{ color: '#8fa0dd', fontSize: 12 }}>
              No dashboards match the current filter.
            </div>
          )}
        </div>
      </div>

      <style>{`
        .inventory-row .row-actions { opacity: 0; transition: opacity 0.2s; }
        .inventory-row:hover .row-actions { opacity: 1; }
        .inventory-row:hover { background: rgba(0,240,255,0.03) !important; }
      `}</style>
    </AppShell>
  );
}

function TableRow({ d }: { d: Dashboard }) {
  return (
    <div
      className="inventory-row grid items-center"
      style={{
        gridTemplateColumns: '2fr 1fr 80px 90px 110px 90px 100px',
        padding: '10px 14px',
        borderBottom: '1px solid rgba(255,255,255,0.03)',
        gap: 8,
        transition: 'background 0.2s',
      }}
    >
      {/* Name */}
      <div>
        <p style={{ fontSize: 11, fontWeight: 600, color: 'white' }}>{d.name}</p>
        <p style={{ fontSize: 9, color: '#8fa0dd', marginTop: 1 }}>{d.workbook}</p>
      </div>

      {/* Source */}
      <span style={{ fontSize: 10, color: '#8fa0dd' }}>{d.source}</span>

      {/* Complexity */}
      <ComplexityBadge c={d.complexity} />

      {/* Status */}
      <StatusPill status={d.status} />

      {/* Calc fields */}
      <div className="flex items-center gap-1.5">
        <div
          className="flex-1 rounded-full overflow-hidden"
          style={{ height: 3, background: 'rgba(255,255,255,0.08)' }}
        >
          <div
            style={{
              width: `${(d.fields / MAX_FIELDS) * 100}%`,
              height: '100%',
              background: fieldBarColor[d.status],
              borderRadius: '100px',
            }}
          />
        </div>
        <span style={{ fontSize: 9, color: '#8fa0dd', fontWeight: 600, flexShrink: 0 }}>{d.fields}</span>
      </div>

      {/* Data source */}
      <span style={{ fontSize: 9, color: '#8fa0dd' }}>{d.dataSource}</span>

      {/* Action */}
      <ActionButtons status={d.status} />
    </div>
  );
}

function StatCard({ icon, label, value, valueColor, sub, subColor }: {
  icon: string; label: string; value: string; valueColor?: string; sub: string; subColor: string;
}) {
  return (
    <div style={{
      background: 'rgba(13,17,39,0.60)',
      backdropFilter: 'blur(12px)',
      border: '1px solid rgba(255,255,255,0.06)',
      borderRadius: 10,
      padding: '10px 12px',
    }}>
      <div className="flex items-center gap-1 mb-1">
        <span style={{ fontSize: 9 }}>{icon}</span>
        <span style={{ fontSize: 9, fontWeight: 600, color: '#8fa0dd', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>
      </div>
      <p style={{ fontSize: 18, fontWeight: 800, color: valueColor || '#f1f3f9', lineHeight: 1 }}>{value}</p>
      <p style={{ fontSize: 9, color: subColor, marginTop: 3 }}>{sub}</p>
    </div>
  );
}
